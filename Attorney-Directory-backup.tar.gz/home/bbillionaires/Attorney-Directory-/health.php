<?php echo "OK • PHP " . PHP_VERSION . " • " . date('c'); ?>
