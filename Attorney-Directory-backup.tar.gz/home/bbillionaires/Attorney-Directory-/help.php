<?
include_once("conn.php");
include_once("includes.php");

include_once("templates/HeaderTemplate.php");

include_once("templates/HelpTemplate.php");

include_once("templates/FooterTemplate.php");

?>