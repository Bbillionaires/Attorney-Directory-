<?
require_once("conn.php");
require_once("includes.php");

//get the templates
require_once("templates/HeaderTemplate.php");
echo "<br><br><center>I am sorry, there was an error with your subscription, either you have already subscribed for there was a problem with your email address. Please try again.</center>";
require_once("templates/FooterTemplate.php");

?>