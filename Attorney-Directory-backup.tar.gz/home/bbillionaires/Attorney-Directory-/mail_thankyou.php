<?
require_once("conn.php");
require_once("includes.php");

//get the templates
require_once("templates/HeaderTemplate.php");
echo "<br><br><center>Thank you for subscribing!</center>";
require_once("templates/FooterTemplate.php");

?>