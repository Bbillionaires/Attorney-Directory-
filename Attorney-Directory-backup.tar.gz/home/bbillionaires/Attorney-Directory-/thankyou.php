<?
include_once("conn.php");
include_once("includes.php");

include_once("templates/HeaderTemplate.php");

include_once("templates/ThankyouTemplate.php");

include_once("templates/FooterTemplate.php");

?>



	


